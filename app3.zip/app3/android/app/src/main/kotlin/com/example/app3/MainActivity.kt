package com.example.app3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
